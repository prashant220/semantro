import React from 'react'
import '../css/footer.css'

function Footer() {
    return (
        <div className="footer">
            <p>Copyright © 2021 Semantro Pvt. Ltd.</p>
        </div>
    )
}

export default Footer
