import React from 'react'

import Body from './Body'


import Navigation from './Navigation'
import Selectfeature from './Selectfeature'




export default function Header() {
    return (
        <div>
           <Navigation/>
           <Body/>
           <Selectfeature/>
        
     

        
      


        
        </div>
    )
}
