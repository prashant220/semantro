

export const feedback="http://3.138.164.184:7000/feedback/"
export const speech="http://3.138.164.184:7000/speech/"
export const contact= "http://103.198.9.169/saayak-web-interface/mutation"